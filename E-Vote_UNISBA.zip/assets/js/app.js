$(document).ready(() => {
    var baseUrl = $('base').attr('href')

    toggleLoading = id => {
        $(`#${id}`).toggleClass('d-none')
    }

    clearConsole = () => {
        console.log(window.console); 
        if(window.console ) {    
            console.clear()  
        }
    }

    toast = (title = '', text = '', icon = 'success') => {
        Swal.fire({
            title: title,
            text: text,
            icon: icon,
            toast: true,
            timer: 3000,
            timerProgressBar: true,
            showConfirmButton: false,
            position: 'top-end',
        })
    }

    $('[title]').tooltip()

    $('.modal').on('shown.bs.modal', function() {
        $('.modal').find('input[type="text"]:first').focus()
    })

    // Get jurusan on edit click
    $('.btn-ubah-jurusan').click(function(e) {
        toggleLoading('loading-modal-ubah-jurusan')
        $('#modal-ubah-jurusan').modal('show')
        let id = $(this).data('id')
        $.get(`${baseUrl}jurusan/get/${id}`, data => {
            if (data.success) {
                $("#modal-ubah-jurusan form").attr('action', `${baseUrl}jurusan/update/${id}`)
                $("#modal-ubah-jurusan form input[name='id']").val(data.data.id_jurusan)
                $("#modal-ubah-jurusan form input[name='nama']").val(data.data.nama_jurusan)
                toggleLoading('loading-modal-ubah-jurusan')
            } else {
                Swal.fire({
                    title: 'Terjadi Kesalahan',
                    text: 'Gagal mendapatkan data',
                    icon: 'error',
                })
            }
        })
        e.preventDefault()
    })

    // Get kelas on jurusan change
    $('#select-jurusan').change(function() {
        let jurusan = $(this).val()
        getKelas(jurusan)
    })

    // Get kelas
    getKelas = jurusan => {
        $('#btn-tambah-kelas').addClass('d-none')
        $("#form-add-kelas input[name='jurusan']").val(jurusan)
        $.get(`${baseUrl}kelas/get/${jurusan}`, data => {
            $('#table-kelas tbody').html('')
            $('#btn-tambah-kelas').removeClass('d-none')
            $.each(data, (key, data) => {
                $('#table-kelas tbody').append(`
                    <tr>
                        <td>${key + 1}</td>
                        <td>${data.nama_kelas}</td>
                        <td>${data.angkatan}</td>
                        <td align="center">
                            <a href="javascript:void(0)" title='Ubah' class="btn-ubah-kelas" data-id="${data.id_kelas}"><i class="fas fa-edit"></i></a>
                            <a href="javascript:void(0)" title='Hapus' class="btn-delete-kelas" data-nama="${data.nama_kelas}" data-id="${data.id_kelas}"><i class="fas fa-trash text-danger ml-2"></i></a>
                        </td>
                    </tr>
                `)
            })
        })
    }

    // Insert kelas
    $('#form-add-kelas').submit(function(e) {
        const jurusan = $("#form-add-kelas input[name='jurusan']").val()
        $.ajax({
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: data => {
                getKelas(jurusan)
                toast(data.success ? 'Berhasil!' : 'Gagal!', data.msg, data.success ? 'success' : 'error')
                $("#form-add-kelas").trigger('reset').find('input:first').focus()
            }
        })
        e.preventDefault()
    })

    // Delete kelas
    $('#table-kelas').on('click', '.btn-delete-kelas', function(e) {
        let id = $(this).data('id'), nama = $(this).data('nama'), jurusan = $("#form-add-kelas input[name='jurusan']").val()
        console.log(id)
        Swal.fire({
            title: 'Anda Yakin?',
            text: `Apakah anda yakin ingin menghapus kelas ${nama}?`,
            icon: 'question',
            showCancelButton: true,
        }).then(result => {
            if (result.value) {
                $.get(`${baseUrl}kelas/delete/${id}`, data => {
                    getKelas(jurusan)
                    toast(data.success ? 'Berhasil!' : 'Gagal!', data.msg, data.success ? 'success' : 'error')
                })
            }
        })
    })

    // Get kelas on edit click
    $('#table-kelas').on('click', '.btn-ubah-kelas', function() {
        let id = $(this).data('id')
        $.get(`${baseUrl}kelas/get/${id}`, data => {
            data = data[0]
            $("#modal-ubah-kelas form").attr('action', `${baseUrl}kelas/update/${id}`)
            $("#modal-ubah-kelas form input[name='nama']").val(data.nama_kelas)
            $("#modal-ubah-kelas form input[name='angkatan']").val(data.angkatan)
            $('#modal-ubah-kelas').modal('show')
        })
    })
})

