<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pemilih extends CI_Model {
    
}